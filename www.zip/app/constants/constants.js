angular.module('kpApp.constant').constant('CONSTANT', {

		STATUS:{
			SUCCESS:'SUCCESS',
			FAILURE:'FAILURE'
		},

		ERROR_CODE:{

		},
		APIPATH:{
			URL:'http://localhost:3000/api/',
			VERSION:'1'
		}
 });
