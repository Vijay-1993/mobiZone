angular.module('kpApp.constant').constant('myConfig', {
	'backend': 'http://127.0.0.1:8080/',
  'version': 0.1
});
